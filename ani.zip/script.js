const imageElement = document.getElementById('animation');
const timestampElement = document.getElementById('timestamp');
const totalFrames = 1500; // Total number of frames
let currentFrame = 0;
let startTime = Date.now();
function updateFrame() {
   imageElement.src = `frame_${currentFrame}.jpg`;
   currentFrame = (currentFrame + 1) % totalFrames;
   updateTimestamp();
}
function updateTimestamp() {
   const elapsedTime = (Date.now() - startTime) / 1000;
   timestampElement.textContent = `Time: ${elapsedTime.toFixed(1)}s`;
}
// Change frame every 50 milliseconds (20 frames per second)
setInterval(updateFrame, 50);
